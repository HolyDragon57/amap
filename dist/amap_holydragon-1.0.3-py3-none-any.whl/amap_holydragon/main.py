from amap_holydragon.amap import amap
# from amap import amap

if __name__ == '__main__':
    amap()
